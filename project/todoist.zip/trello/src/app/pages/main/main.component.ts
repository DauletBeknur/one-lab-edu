import { Component, OnInit } from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import {Board} from '../../models/board.model';
import {Column} from '../../models/column.model';
import {AuthService} from '../../auth/auth.service';
import {AngularFirestore} from '@angular/fire/firestore';
import {Router} from '@angular/router';
import {Observable} from 'rxjs';


@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css'],
})
export class MainComponent implements OnInit {
  user: firebase.User;
  constructor() {
  }

  board: Board = new Board('Your Board', [
    new Column('Ideas', [
      'Realize new feature',
      'Try GTD system'
    ]),
    new Column('Research', [
      'Django',
      'Angular'
    ]),
    new Column('To Do', [
      'Feed my turtle',
      'Write an essay'
    ]),
    new Column('Done', [
      'Read the book',
      'Take a shower'
    ]),
  ]);

  ngOnInit(): void {}

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
    }
  }
}
