import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  authError: any;
  registerForm: FormGroup;

  constructor(private auth: AuthService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.auth.eventAuthError$.subscribe(data => {
      this.authError = data;
    });
    this.registerForm = this.formBuilder.group({
      firstName: new FormControl(null, [
        Validators.required,
        Validators.minLength(3)
      ]),
      lastName: new FormControl(null, [
        Validators.required,
        Validators.minLength(3)
      ]),
      email: new FormControl(null, [
        Validators.required,
        Validators.email
      ]),
      password: new FormControl(null, [
        Validators.required,
        Validators.minLength(6)
      ]),
      confirmPassword: new FormControl(null, [
        Validators.required,
        Validators.minLength(6)
      ])
    });
  }

  createUser(frm) {
    this.auth.createUser(frm.value);
  }

}
