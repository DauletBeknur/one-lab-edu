export class Column {
  constructor(public name: string, public tasks: string[]) {}
}
