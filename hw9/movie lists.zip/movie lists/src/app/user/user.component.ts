import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth/auth.service';
import {Router} from '@angular/router';
import { AngularFireDatabase } from '@angular/fire/database';
import { AngularFirestore } from '@angular/fire/firestore';
import 'firebase/database';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  users: Observable<any>;

  constructor(private auth: AuthService,
              firestore: AngularFirestore,
              private router: Router) {
    this.users = firestore.collection('Users').valueChanges();
  }

  ngOnInit(): void {
  }

}
