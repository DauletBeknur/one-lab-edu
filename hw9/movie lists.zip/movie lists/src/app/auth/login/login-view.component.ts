import {Component, Input, OnInit, Output, EventEmitter} from '@angular/core';
import {faExclamationCircle} from '@fortawesome/free-solid-svg-icons';
// import {AuthUser} from '../auth_user';

@Component({
  selector: 'app-login-view',
  templateUrl: './login-view.component.html',
  styleUrls: ['./login-view.component.css']
})
export class LoginViewComponent implements OnInit {


  constructor() {
  }

  ngOnInit(): void {
  }

}
