import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './auth/login/login.component';
import {RouterModule} from '@angular/router';
import { LoginViewComponent } from './auth/login/login-view.component';
import {FormsModule} from '@angular/forms';
import {AuthService} from './auth/auth.service';
import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';
import { environment } from '../environments/environment';
import { MatSliderModule } from '@angular/material/slider';
import { RegistrationComponent } from './auth/registration/registration.component';
import { UserComponent } from './user/user.component';
import { MoviesComponent } from './movies/movies.component';
import {MatCardModule} from '@angular/material/card';
import { DetailMovieComponent } from './detail-movie/detail-movie.component';
import { StoreModule } from '@ngrx/store';
import { counterReducer } from './counter.reducer';
import { MycounterComponent } from './mycounter/mycounter.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    LoginViewComponent,
    RegistrationComponent,
    UserComponent,
    MoviesComponent,
    DetailMovieComponent,
    MycounterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    RouterModule,
    FormsModule,
    MatSliderModule,
    MatCardModule,
    AngularFireAuthModule,
    AngularFirestoreModule,
    AngularFireModule.initializeApp(environment.firebase),
    BrowserModule,
    StoreModule.forRoot({ count: counterReducer })
  ],
  providers: [AuthService, AngularFirestore ],
  bootstrap: [AppComponent]
})
export class AppModule { }
