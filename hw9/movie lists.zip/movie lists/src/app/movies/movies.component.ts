import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs';
import {AuthService} from '../auth/auth.service';
import {Router} from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';

export interface Tile {
  color: string;
  cols: number;
  rows: number;
  text: string;
}

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {
  movies: Observable<any>;


  constructor(private auth: AuthService,
              firestore: AngularFirestore,
              private router: Router) {
    this.movies = firestore.collection('Movies').valueChanges();
  }

  ngOnInit(): void {
  }

}
