// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyDOeg6rkH3rL8U_ZR9TN-bqi6Mhh2dNLvo',
    authDomain: 'myapp-d2e03.firebaseapp.com',
    databaseURL: 'https://myapp-d2e03.firebaseio.com',
    projectId: 'myapp-d2e03',
    storageBucket: 'myapp-d2e03.appspot.com',
    appId: '1:805740335494:web:fb832f4a9955dbf65edc07',
    messagingSenderId: '805740335494'
  }
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
