import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-shiny-button',
  templateUrl: './shiny-button.component.html',
  styleUrls: ['./shiny-button.component.css']
})
export class ShinyButtonComponent implements OnInit {
@Input('color') public color: string;
@Output('onColorChange') public colorEventEmitter: EventEmitter<string> = new EventEmitter();
@Input('position') public borderRadius: string;
@Output('onPositionChange') public positionEventEmitter: EventEmitter<string> = new EventEmitter();
public position: string;
constructor() {
   this.color = this.generateRandomColor();
   this.borderRadius = '50%';
   this.position = this.generatePosition();
}


  ngOnInit() {}

  generateRandomColor() {
  const newColor = '#' + ((Math.random() * 0xffffff) << 0).toString(16);
  this.colorEventEmitter.next(newColor);
  return newColor;
  }

  changeColor() {
   this.color = this.generateRandomColor();
}

 changeForm() {
     if(this.borderRadius==="50%")
    this.borderRadius = "0.5rem";
    else this.borderRadius = "50%";
}

 generatePosition() {
  const newPosition = (Math.floor(Math.random()*200)).toString() + "px";
  this.positionEventEmitter.next(newPosition);
  return newPosition;
}

 changePosition() {
   this.position = this.generatePosition();
}

}
